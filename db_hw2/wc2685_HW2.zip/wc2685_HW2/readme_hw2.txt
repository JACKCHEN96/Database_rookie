uni: wc2685
name: Wenjie Chen


In this assignment, I complete the following things:


1. Understand and apply advanced SQL query capabilities
Complete the written homework including six questions and submit it as a PDF.


2. Understand the Schema and write queries:
This portion of the homework assignment is based on the Lahman baseball statistics database. There are 6 queries in the homework assignment. 

I gain understanding on: Select, Insert, Update, Delete, Limit, Offset, Join, Create views, Order by...in SQL. I submit it as a .sql file.


3. Implement a RESTful API in python to understand how to surface data from the web:
Use Flask to connects to a local host where we can send HTTP requests. 

Use Postman to connect to the local host so that we can test our code. 

Add methods to data_table_adaptor.py including (get_databases, get_tables...) and RDBDataTable.py including(get_row_count, get_primary_key_columns...).

Default @app.routes to show how paths come in and are handled in python in app.py. Process GET, POST, PUT and DELETE requests by converting the input string into a where clause, and send it to SQL to obtain the response, and then return the result on Postman. I do and test the following:
1.
@application.route("/api/databases", methods=["GET"])
def dbs():
2.
@application.route("/api/databases/<dbname>", methods=["GET"])
def tbls(dbname):
3.
@application.route('/api/<dbname>/<resource>/<primary_key>', methods=['GET', 'PUT', 'DELETE'])
def resource_by_id(dbname, resource, primary_key):
4.
@application.route('/api/<dbname>/<resource_name>', methods=['GET', 'POST'])
def get_resource(dbname, resource_name):


And I screenshot all the test result (test GET PUT DELETE POST...seperately) and submit it as a PDF.


So it will be:
---Written(wc2685_HW2.pdf)
---SQL(wc2685_HW2.sql)
---Code(HW2 Template, db_screenshots_hw2.pdf)

Please contact wc2685@columbia.edu, if anything goes wrong with this HW.




